import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.white,

        body: SafeArea(
          child: Column(
            children: [
              SizedBox(height: 50),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image(
                    image: AssetImage('assets/khan.jpeg'),
                    width: 50,
                    height: 50,
                  ),
                  SizedBox(width: 10),

                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Maintainancee',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Box',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Color(0xffF9703B)
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 10),
              Center(
                child: Text(
                  'Login',
                  style: TextStyle(fontSize: 24, fontFamily: 'Rubik',fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 14),
              Center(
                child: Text(
                  'I want to make a login page\n that every one ',
                  textAlign: TextAlign.center,

                  style: TextStyle(
                    fontSize: 16,
                    fontFamily: 'Rubik',
                    color: Colors.grey,
                  ),
                ),
              ),
              SizedBox(height: 50,),
              Padding(padding: EdgeInsets.only(left: 20,right: 20),
            child:TextFormField(
                decoration: InputDecoration(
                  hintText: 'Email',
                  fillColor: Color(0xffF8F9FA),
                  filled: true,
                  prefixIcon: Icon(Icons.email,color: Color(0xff323F4B),),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Color(0xffE4E7EB)),
                    borderRadius: BorderRadius.circular(10)
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:const BorderSide(color: Color(0xffE4E7EB)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
             Padding(
               padding: EdgeInsets.only(left: 20,right: 20,top: 10),
              child:TextFormField(
                decoration: InputDecoration(
                  hintText: 'Password',
                  fillColor: Color(0xffF8F9FA),
                  filled: true,
                  prefixIcon: Icon(Icons.lock,color: Color(0xff323F4B),),
                  suffixIcon: Icon(Icons.visibility_off_rounded),
                  focusedBorder: OutlineInputBorder(
                    borderSide:const BorderSide(color: Color(0xffE4E7EB)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide:const BorderSide(color: Color(0xffE4E7EB)),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
             ),
              Padding(padding:EdgeInsets.only(left: 200) ,
                child: Text('Forget Password?',style: TextStyle(decoration: TextDecoration.underline,),),
              ),

              SizedBox(height: 100,),

              Container(
                height: 50,
                width:300,

                decoration: BoxDecoration(
                    color: Color(0xffF9703B),
                  borderRadius: BorderRadius.circular(10)
                ),
                child: Center(child: Text('Login',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: Colors.white),),),
              
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 15,),
                  Center(
                    child: Text('Dont have an Account?',style: TextStyle(fontSize: 16),),
                  ),
                  Center(
                    child: Text('Signup',style: TextStyle(color: Color(0xffF9703B)),),
                  )
                ],
              ),

            ],
          ),
        ),
      ),
    );
  }
}
